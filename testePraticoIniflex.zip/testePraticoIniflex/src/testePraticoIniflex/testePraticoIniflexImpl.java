package testePraticoIniflex;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class testePraticoIniflexImpl {
	public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();

        // 3.1 - Inserir todos os funcionários
        funcionarios.add(new Funcionario("Maria", LocalDate.of(2000, Month.OCTOBER, 18), new BigDecimal("2009.44"), "Operador"));
        funcionarios.add(new Funcionario("João", LocalDate.of(1990, Month.MAY, 12), new BigDecimal("2284.38"), "Operador"));
        funcionarios.add(new Funcionario("Caio", LocalDate.of(1991, Month.MAY, 2), new BigDecimal("9836.14"), "Cordenador"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.of(1988, Month.OCTOBER, 14), new BigDecimal("19119.88"), "Diretor"));
        funcionarios.add(new Funcionario("Alice", LocalDate.of(1995, Month.JANUARY, 5), new BigDecimal("2234.68"), "Recepcionista"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.of(1999, Month.NOVEMBER, 19), new BigDecimal("1582.72"), "Operador"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.of(1993, Month.MARCH, 31), new BigDecimal("4071.84"), "Contador"));
        funcionarios.add(new Funcionario("Laura", LocalDate.of(1994, Month.SEPTEMBER, 8), new BigDecimal("3017.45"), "Gerente"));
        funcionarios.add(new Funcionario("Heloísa", LocalDate.of(2003, Month.MAY, 24), new BigDecimal("1606.85"), "Eletricista"));
        funcionarios.add(new Funcionario("Helena", LocalDate.of(1996, Month.JULY, 2), new BigDecimal("2799.93"), "Gerente"));

        // 3.2 - Remover o funcionário "João" da lista        
        funcionarios.removeIf(funcionario -> funcionario.getNome().equals("João"));        
        
        // 3.3 - Imprimir todos os funcionários com todas suas informações, sendo que:
        //       • informação de data deve ser exibido no formato dd/mm/aaaa;
        //       • informação de valor numérico deve ser exibida no formatado com separador de milhar como ponto e decimal como vírgula.
        System.out.println("Imprimir todos os funcionários");        
        DecimalFormat decimalFormat = new DecimalFormat("#,###.00");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        for (Funcionario funcionario : funcionarios) {
            String salarioFormatado = decimalFormat.format(funcionario.getSalario());
            String dataFormatada = funcionario.getDataNascimento().format(dateFormatter);
            System.out.println("Nome: " + funcionario.getNome() + ", Data de Nascimento: " + dataFormatada +
                    ", Salário: R$" + salarioFormatado + ", Função: " + funcionario.getFuncao());
        }
        System.out.println();

        // 3.4 - Os funcionários receberam 10% de aumento de salário, atualizar a lista de funcionários com novo valor.
        System.out.println("Aumentar salário em 10%");        
        for (Funcionario funcionario : funcionarios) {
        	BigDecimal salarioAtual = funcionario.getSalario();
        	BigDecimal aumento = salarioAtual.multiply(new BigDecimal("0.10")); // 10% de aumento
            BigDecimal novoSalario = salarioAtual.add(aumento);
            funcionario.setSalario(novoSalario);
            System.out.println("Nome: " + funcionario.getNome() + ", Novo Salário: R$" + decimalFormat.format(novoSalario));
        }
        System.out.println();
        
        // 3.5 - Agrupar os funcionários por função em um MAP, sendo a chave a “função” e o valor a “lista de funcionários”.        
        Map<String, List<Funcionario>> funcionariosPorFuncao = funcionarios.stream()
                .collect(Collectors.groupingBy(Funcionario::getFuncao));

        // 3.6 - Imprimir funcionários agrupados por função
        System.out.println("Imprimir funcionários agrupados por função");        
        for (Map.Entry<String, List<Funcionario>> entry : funcionariosPorFuncao.entrySet()) {
            System.out.println("Funcionários da função '" + entry.getKey() + "':");
            for (Funcionario funcionario : entry.getValue()) {
                System.out.println("Nome: " + funcionario.getNome() + ", Salário: R$" +
                        decimalFormat.format(funcionario.getSalario()));
            }
        }
        System.out.println();

        // 3.8 - Imprimir os funcionários que fazem aniversário no mês 10 e 12.
        // Como na planilha não temos ninguem nascido em Dezembro está trazendo apenas o mês 10, mas se mudarmos alguém para mês 12 esse aparece na lista
        System.out.println("Imprimir funcionários com aniversário em outubro (mês 10) e dezembro (mês 12)");
        Month[] mesesAniversario = {Month.OCTOBER, Month.DECEMBER};
        LocalDate hoje = LocalDate.now();
        for (Funcionario funcionario : funcionarios) {
            if (Arrays.asList(mesesAniversario).contains(funcionario.getDataNascimento().getMonth())) {
                String dataFormatada = funcionario.getDataNascimento().format(dateFormatter);
                System.out.println("Nome: " + funcionario.getNome() + ", Data de Nascimento: " + dataFormatada);
            }
        }
        System.out.println();

        // 3.9 - Imprimir o funcionário com a maior idade, exibir os atributos: nome e idade.
        System.out.println("Encontrar funcionário mais velho");
        LocalDate dataAtual = LocalDate.now();
        Funcionario funcionarioMaisVelho = Collections.min(funcionarios, Comparator.comparing(
                f -> f.getDataNascimento().until(dataAtual).getDays()
        ));
        Period idade = Period.between(funcionarioMaisVelho.getDataNascimento() , dataAtual);
        int anos = idade.getYears();
        System.out.println("Funcionário mais velho: Nome: " + funcionarioMaisVelho.getNome() + ", Idade: " + anos + " anos");
        System.out.println();
        
        // 3.10 -  Imprimir a lista de funcionários por ordem alfabética.
        System.out.println("Ordenar e imprimir funcionários por ordem alfabética");        
        funcionarios.sort(Comparator.comparing(Funcionario::getNome));
        for (Funcionario funcionario : funcionarios) {
            System.out.println("Nome: " + funcionario.getNome());
        }
        System.out.println();
        
        // 3.11 - Imprimir o total dos salários dos funcionários.
        System.out.println("Calcular total dos salários");
        BigDecimal totalSalarios = funcionarios.stream()
                .map(Funcionario::getSalario)
                //.map(Funcionario.novoSalario)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        System.out.println("Total dos salários: R$" + decimalFormat.format(totalSalarios));
        System.out.println();

        // 3.12 - Imprimir quantos salários mínimos ganha cada funcionário, considerando que o salário mínimo é R$1212.00.
        System.out.println("Calcular quantos salários mínimos cada funcionário ganha");
        BigDecimal salarioMinimo = new BigDecimal("1212.00");
        for (Funcionario funcionario : funcionarios) {
            BigDecimal salarioEmSalariosMinimos = funcionario.getSalario().divide(salarioMinimo, 2, BigDecimal.ROUND_DOWN);
            System.out.println("Funcionário " + funcionario.getNome() + " ganha " + salarioEmSalariosMinimos +
                    " salários mínimos.");
        }
    }

}
